const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-this-password";
const ROOT = __dirname;
const DATA = path.join(ROOT, "data");
const PUBLIC = path.join(ROOT, "public");

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(PUBLIC));

function read(name){ return JSON.parse(fs.readFileSync(path.join(DATA,name),"utf8")); }
function write(name,data){ fs.writeFileSync(path.join(DATA,name), JSON.stringify(data,null,2)); }
function makeCode(){
  let codes = read("codes.json");
  let code;
  do {
    const a = crypto.randomBytes(4).toString("hex").toUpperCase();
    const b = crypto.randomBytes(5).toString("base64url").replace(/[-_]/g,"").slice(0,7).toUpperCase();
    code = `patapem-${a}-${b}_`;
  } while(codes.some(x=>x.code===code));
  return code;
}
function admin(req,res,next){
  const token = req.headers["x-admin-token"];
  if(token !== process.env.ADMIN_TOKEN && token !== ADMIN_PASSWORD) return res.status(401).json({error:"Unauthorized"});
  next();
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_,__,cb)=>cb(null,path.join(DATA,"slips")),
    filename: (_,file,cb)=>cb(null,Date.now()+"-"+crypto.randomBytes(4).toString("hex")+path.extname(file.originalname))
  }),
  limits:{fileSize: 8*1024*1024},
  fileFilter: (_,file,cb)=>cb(null,/^image\/(png|jpeg|webp)$|^application\/pdf$/.test(file.mimetype))
});

app.get("/api/products",(req,res)=>res.json(read("products.json")));

app.post("/api/orders",(req,res)=>{
  const {productId, quantity=1, editMinutes, paymentMethod} = req.body;
  const products = read("products.json");
  let product = products.find(p=>p.id===productId);
  let price = 0, name = "";
  if(product){ price = product.price * Math.max(1,Number(quantity)); name = product.name; }
  else if(productId==="edit-service"){
    const mins = Math.min(60,Math.max(1,Number(editMinutes)||1));
    price = mins * 10; name = `รับตัดต่อ ${mins} นาที`;
  } else return res.status(400).json({error:"ไม่พบสินค้า"});
  const orders = read("orders.json");
  const orderId = "PEM-" + Date.now().toString(36).toUpperCase() + "-" + crypto.randomBytes(2).toString("hex").toUpperCase();
  const order = {orderId, productId, name, quantity:Number(quantity)||1, editMinutes:Number(editMinutes)||null, total:price, paymentMethod:paymentMethod||"manual", status:"รอตรวจสอบการชำระเงิน", code:null, createdAt:new Date().toISOString()};
  orders.push(order); write("orders.json",orders);
  res.json(order);
});

app.post("/api/orders/:id/slip", upload.single("slip"), (req,res)=>{
  const orders = read("orders.json");
  const order = orders.find(o=>o.orderId===req.params.id);
  if(!order) return res.status(404).json({error:"ไม่พบคำสั่งซื้อ"});
  if(!req.file) return res.status(400).json({error:"กรุณาแนบสลิป"});
  order.slipFile = req.file.filename;
  order.status = "รอตรวจสอบสลิป";
  write("orders.json",orders);
  res.json({ok:true,status:order.status});
});

app.get("/api/orders/:id",(req,res)=>{
  const order = read("orders.json").find(o=>o.orderId===req.params.id);
  if(!order) return res.status(404).json({error:"ไม่พบคำสั่งซื้อ"});
  res.json(order);
});

app.post("/api/check-code",(req,res)=>{
  const {code} = req.body;
  const item = read("codes.json").find(x=>x.code===String(code||"").trim());
  if(!item) return res.json({found:false,message:"ไม่พบโค้ดนี้ในระบบ"});
  res.json({found:true, code:item.code, product:item.productName, used:!!item.used, usedAt:item.usedAt||null});
});

/* Admin */
app.get("/api/admin/orders",admin,(req,res)=>res.json(read("orders.json")));
app.get("/api/admin/codes",admin,(req,res)=>res.json(read("codes.json")));

app.post("/api/admin/generate",admin,(req,res)=>{
  const products = read("products.json");
  const p = products.find(x=>x.id===req.body.productId);
  if(!p) return res.status(400).json({error:"ไม่พบสินค้า"});
  const codes = read("codes.json");
  const count = Math.min(1000,Math.max(1,Number(req.body.count)||1));
  const created = [];
  for(let i=0;i<count;i++){
    const item = {code:makeCode(), productId:p.id, productName:p.name, used:false, usedAt:null, createdAt:new Date().toISOString()};
    codes.push(item); created.push(item);
  }
  write("codes.json",codes);
  res.json({created});
});

app.post("/api/admin/use-code",admin,(req,res)=>{
  const codes = read("codes.json");
  const item = codes.find(x=>x.code===String(req.body.code||"").trim());
  if(!item) return res.status(404).json({error:"ไม่พบโค้ด"});
  item.used=true; item.usedAt=new Date().toISOString();
  write("codes.json",codes);
  res.json(item);
});

app.post("/api/admin/orders/:id/approve",admin,(req,res)=>{
  const orders = read("orders.json");
  const order = orders.find(o=>o.orderId===req.params.id);
  if(!order) return res.status(404).json({error:"ไม่พบคำสั่งซื้อ"});
  if(!order.code){
    const codes = read("codes.json");
    const candidate = codes.find(c=>c.productId===order.productId && !c.used);
    if(candidate){ order.code=candidate.code; order.status="ชำระเงินยืนยันแล้ว / พร้อมส่ง"; }
    else order.status="ชำระเงินยืนยันแล้ว / รอโค้ดสินค้า";
    write("codes.json",codes);
  } else order.status="ชำระเงินยืนยันแล้ว / พร้อมส่ง";
  write("orders.json",orders);
  res.json(order);
});

app.listen(PORT,()=>console.log(`PATAPEMSHOP running on http://localhost:${PORT}`));
