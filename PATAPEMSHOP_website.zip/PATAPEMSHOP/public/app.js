const $=s=>document.querySelector(s);
const money=n=>new Intl.NumberFormat("th-TH").format(n);
async function loadProducts(){
  const products=await fetch("/api/products").then(r=>r.json());
  const grid=$("#productGrid"), q=$("#search");
  function render(){
    const term=(q.value||"").toLowerCase();
    grid.innerHTML=products.filter(p=>p.name.toLowerCase().includes(term)).map(p=>`
      <article class="glass card">
        <img src="${p.image}" alt="${p.name}">
        <h3>${p.name}</h3>
        <div class="price">${money(p.price)}</div>
        <button class="btn primary buy" data-id="${p.id}">สั่งซื้อ</button>
      </article>`).join("");
    document.querySelectorAll(".buy").forEach(b=>b.onclick=()=>order(b.dataset.id));
  }
  q.oninput=render; render();
}
async function order(productId){
  const paymentMethod=prompt("วิธีชำระเงิน: bank หรือ red-envelope","bank")||"bank";
  const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productId,paymentMethod})});
  const o=await res.json();
  if(o.orderId) alert(`สร้างคำสั่งซื้อแล้ว\\nหมายเลข: ${o.orderId}\\nยอด: ${o.total}\\nสถานะ: ${o.status}`);
  else alert(o.error||"เกิดข้อผิดพลาด");
}
$("#mins").oninput=e=>{$("#minsOut").textContent=e.target.value+" นาที";$("#editPrice").textContent=money(+e.target.value*10)};
$("#editOrder").onclick=async()=>{
  const mins=+$("#mins").value;
  const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productId:"edit-service",editMinutes:mins,paymentMethod:"bank"})});
  const o=await res.json();
  alert(`สร้างคำสั่งซื้อแล้ว\\nหมายเลข: ${o.orderId}\\n${o.name}\\nยอด: ${o.total}`);
};
$("#sendSlip").onclick=async()=>{
  const id=$("#orderForSlip").value.trim(), file=$("#slip").files[0];
  if(!id||!file) return $("#slipMsg").textContent="กรุณาใส่เลขคำสั่งซื้อและเลือกไฟล์สลิป";
  const fd=new FormData(); fd.append("slip",file);
  const r=await fetch(`/api/orders/${encodeURIComponent(id)}/slip`,{method:"POST",body:fd});
  const d=await r.json(); $("#slipMsg").textContent=d.status||d.error||"เสร็จแล้ว";
};
$("#checkCode").onclick=async()=>{
  const code=$("#codeInput").value.trim();
  const d=await fetch("/api/check-code",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})}).then(r=>r.json());
  $("#codeResult").innerHTML=d.found
   ? `<div class="check glass ${d.used?"bad":"ok"}"><b>${d.used?"❌ ใช้แล้ว":"✅ ยังไม่ถูกใช้"}</b><br>สินค้า: ${d.product}<br>โค้ด: ${d.code}${d.usedAt?`<br>ใช้เมื่อ: ${new Date(d.usedAt).toLocaleString("th-TH")}`:""}</div>`
   : `<div class="check glass bad">❌ ${d.message}</div>`;
};
document.addEventListener("pointerdown",e=>{
  const r=document.createElement("span"); r.className="ripple"; r.style.left=e.clientX+"px";r.style.top=e.clientY+"px";document.body.appendChild(r);setTimeout(()=>r.remove(),850);
  const s=document.createElement("span"); s.className="scan-ring"; s.style.left=e.clientX+"px";s.style.top=e.clientY+"px";document.body.appendChild(s);setTimeout(()=>s.remove(),950);
});
loadProducts();
